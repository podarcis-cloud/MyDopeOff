# MyDope Off — paquet de déploiement (révisé & corrigé)

Version reprise par audit : corrections critiques, sécurité, régionalisation
multilingue, PWA. Déployable sur un hébergement statique (GitHub Pages, Netlify…).

## Déploiement
1. Servir le contenu de ce dossier à la racine du site (HTTPS requis pour le SW).
2. Vérifier que `assets/`, `icons/`, `sw.js` et `manifest.json` sont accessibles.
3. Le service worker (`sw.js`) gère le hors-ligne ; bump la version de cache à
   chaque mise à jour (`CACHE = 'mydopeoff-vXX'`).

## Arborescence
```
/ (racine)
├── index.html  inscription.html  suivi.html  psychochecker.html
│   rdr.html  controles.html                ← pages reconstruites/corrigées
├── fiches.html  guide.html  soutenir.html  maze.html  tetris.html
│                                            ← pages secondaires (à migrer sur le socle)
├── assets/
│   ├── css/  tokens.css  components.css     ← design system (source unique)
│   └── js/
│        ├── i18n.js  regions.js  core.js    ← socle partagé (remplace les copies inline)
│        ├── interactions-fix.js  interactions-data.js
│        │   substance-classes.js  new-substances.js   ← moteur d'interactions corrigé
│        ├── detection-data.js               ← fenêtres de détection vérifiées/sourcées
│        └── page-*.js                        ← logique de page externalisée (pour CSP)
├── icons/  icon-192.png  icon-512.png  icon-512-maskable.png  apple-touch-icon.png
├── sw.js   manifest.json
└── lucide.js  lucide.css  *-i18n.js          ← dépendances des pages secondaires (legacy)
```

## Ce qui a été corrigé (résumé)
- **CRITIQUE — vérificateur d'interactions** : le bug qui affichait toutes les
  interactions en « danger » et l'inconnu en « vert/safe » est corrigé. Gravité =
  donnée structurée (danger/risque/prudence/info), inconnu = prudence (jaune),
  jamais vert. Matching par identifiant canonique strict. Filet de sécurité par
  classe couvrant les 270 fiches. (`interactions-*.js`, `substance-classes.js`)
- **CRITIQUE — fuite de données** : l'identité (prénom/âge) ne transite plus par
  l'URL (profil 100 % localStorage). Clé API IA retirée. CSP + `referrer:no-referrer`.
- **Détection** : fenêtres vérifiées/sourcées ; cocaïne salive 1–24 h → 1–48 h ;
  avertissement salive ≠ urine ≠ cheveux ; sources affichées. (`detection-data.js`)
- **Contenu ajouté** : poppers + solvants (fiches, interactions, détection) ;
  protocole overdose/naloxone ; sevrage alcool/benzo.
- **Régionalisation** : `regions.js` = source unique des données RDR **et**
  légales/routières (BE/FR/CH/CA/LU) — urgences, centres, naloxone, statut cannabis,
  alcoolémie, sanctions, avec dates de vérification. Pages `rdr.html` et
  `controles.html` régionalisées et multilingues (FR/EN/ES/DE).
- **Architecture** : socle unique (`core.js`/`i18n.js`) au lieu de 6 copies inline ;
  design system (`tokens.css`/`components.css`).
- **PWA** : service worker à deux niveaux (noyau obligatoire vs best-effort),
  icônes PNG, manifest mis à jour.

## ⚠️ Avant mise en production — réserves importantes
- **Relecture experte obligatoire** : les données médicales (interactions,
  gravités re-taguées, fenêtres de détection) et **légales** (statuts, seuils,
  sanctions) doivent être validées par un·e addictologue/pharmacien·ne et un·e
  juriste. Les champs `verifie_le`/`source` sont prévus pour l'afficher.
- **Re-vérification annuelle** des statuts légaux et seuils (ils changent).
- **À finaliser** : migration des pages secondaires (`fiches`, `guide`,
  `soutenir`, `maze`, `tetris`) sur le socle ; **self-hosting des polices**
  (Manrope/Inter en `.woff2`) pour un hors-ligne et une confidentialité à 100 %
  (actuellement chargées via Google Fonts, mises en cache par le SW).
- **Politique d'âge** : choix assumé d'un outil RDR ouvert, à documenter
  formellement (CGU) avec avis juridique.

Outil d'information et de réduction des risques. N'encourage pas l'usage et ne
remplace pas un avis médical. Urgence : 112 / 15.
