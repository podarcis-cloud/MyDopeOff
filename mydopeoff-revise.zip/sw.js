/* ============================================================================
   MyDope Off — Service Worker  (v39)
   Corrige MAJEUR-6 : l'installation ne se "réussit" plus en silence quand un
   asset essentiel manque. On sépare :
     • CORE     = coquille minimale indispensable -> addAll (échec => install échoue)
     • OPTIONAL = pages, données lourdes, polices -> allSettled (best-effort)
   Le reste est mis en cache à la volée (runtime). Stratégies :
     • Code app (HTML/JS/CSS) : network-first (toujours la dernière version en ligne,
       repli cache hors-ligne)
     • Polices : cache-first
     • Reste : cache-first
   ============================================================================ */
const CACHE = 'mydopeoff-v39';

/* Coquille indispensable : si l'un de ces fichiers manque, l'install échoue
   (comportement voulu : on ne veut pas d'une PWA à moitié cassée hors-ligne). */
const CORE = [
  './',
  './index.html',
  './manifest.json',
  './assets/css/tokens.css',
  './assets/css/components.css',
  './assets/js/i18n.js',
  './assets/js/regions.js',
  './assets/js/core.js'
];

/* Best-effort : un échec ici n'empêche pas l'installation. Ces ressources
   seront de toute façon mises en cache à la première utilisation (runtime). */
const OPTIONAL = [
  './inscription.html', './suivi.html', './psychochecker.html', './rdr.html',
  './fiches.html', './controles.html', './guide.html', './soutenir.html',
  './maze.html', './tetris.html',
  // Moteur d'interactions + données
  './assets/js/interactions-fix.js', './assets/js/interactions-data.js',
  './assets/js/substance-classes.js', './assets/js/new-substances.js',
  './assets/js/detection-data.js',
  // Icônes
  './icons/icon-192.png', './icons/icon-512.png', './icons/icon-512-maskable.png',
  // Données i18n historiques (tant que les pages legacy ne sont pas migrées)
  './fiches-i18n.js', './rdr-i18n.js', './controles-i18n.js', './guide-i18n.js', './protocols-i18n.js',
  './lucide.js', './lucide.css',
  // Polices (cache-first ensuite). À terme : self-host pour un offline 100%.
  'https://fonts.googleapis.com/css2?family=Manrope:wght@600;700;800&family=Inter:wght@400;500;600&display=swap'
];

self.addEventListener('install', e => {
  e.waitUntil((async () => {
    const c = await caches.open(CACHE);
    await c.addAll(CORE);                                   // échec => install rejetée (voulu)
    await Promise.allSettled(OPTIONAL.map(u => c.add(u)));  // best-effort
    self.skipWaiting();
  })());
});

self.addEventListener('activate', e => {
  e.waitUntil(
    caches.keys()
      .then(ks => Promise.all(ks.filter(k => k !== CACHE).map(k => caches.delete(k))))
      .then(() => self.clients.claim())
  );
});

function isAppCode(url){ return /\.(html|js|css)(\?|$)/.test(url) || url.endsWith('/'); }
function isFont(url){ return url.includes('fonts.googleapis.com') || url.includes('fonts.gstatic.com'); }

self.addEventListener('fetch', e => {
  if (e.request.method !== 'GET') return;
  const url = e.request.url;

  // Polices : cache-first
  if (isFont(url)) {
    e.respondWith(
      caches.match(e.request).then(c => c || fetch(e.request).then(r => {
        const cc = r.clone(); caches.open(CACHE).then(x => x.put(e.request, cc)); return r;
      }))
    );
    return;
  }

  // Code de l'app : network-first (repli cache hors-ligne)
  if (isAppCode(url) || ['document','script','style'].includes(e.request.destination)) {
    e.respondWith(
      fetch(e.request).then(r => {
        if (r && r.status === 200 && r.type !== 'opaque') {
          const c = r.clone(); caches.open(CACHE).then(x => x.put(e.request, c));
        }
        return r;
      }).catch(() => caches.match(e.request).then(c =>
        c || (e.request.destination === 'document' ? caches.match('./index.html') : undefined)
      ))
    );
    return;
  }

  // Reste (images, données) : cache-first
  e.respondWith(
    caches.match(e.request).then(cached => cached || fetch(e.request).then(r => {
      if (r && r.status === 200 && r.type !== 'opaque') {
        const c = r.clone(); caches.open(CACHE).then(x => x.put(e.request, c));
      }
      return r;
    }).catch(() => { if (e.request.destination === 'document') return caches.match('./index.html'); }))
  );
});
