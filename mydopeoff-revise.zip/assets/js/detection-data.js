/* ============================================================================
   MyDope Off — detection-data.js
   Fenêtres de détection VÉRIFIÉES & SOURCÉES (salive / urine / sang).
   Vérifié 2026-06 : Verstraete 2004 (Ther Drug Monit), SAMHSA Oral Fluid
   Program 2023/24, NIDA. Valeurs en HEURES (D = 24 h).

   SÉCURITÉ — ne pas tromper l'utilisateur :
   Salive ≠ urine ≠ cheveux. La salive reflète l'usage RÉCENT (≈ 5–48 h). Les
   « semaines » entendues = CHEVEUX (mois) ou urine en usage chronique.
   Estimations : dose/fréquence/métabolisme changent tout. Après usage, seul
   le temps protège : ne pas conduire.

   Corrections vs version initiale : Cocaïne salive 1–24 h -> 1–48 h ;
   Morphine/Héroïne -> ~36 h ; Méthamphétamine -> ~50 h ; ajout Poppers,
   Solvants, Butane/gaz, Éther (NON détectés en routine).
   ============================================================================ */
(function (global) {
  'use strict';
  var D = 24;
  var DISCLAIMER = "Estimations. La salive reflète l'usage récent (souvent 5–48 h) ; l'urine est plus longue, les cheveux couvrent des mois. Dose, fréquence et métabolisme changent tout. Après usage, seul le temps protège : ne pas conduire.";
  // S(nom, fam, aliases, [salive], [urine], [sang], note, detectable, source)
  function S(nom,fam,al,sal,uri,blo,note,det,src){
    return { nom:nom, fam:fam, aliases:al, sal:sal, uri:uri, blo:blo, note:note, detectable:det!==false, source:src||'' };
  }
  var DETECTION = [
    S("Alcool","depresseur",["éthanol","ethanol","bière","vin","vodka","whisky"],[2,12],[12,2*D],[2,12],"Éthanol disparaît vite ; l'EtG (urine) reste plus longtemps.",true,"Verstraete 2004, Ther Drug Monit (oral fluid 5–48 h) · SAMHSA Oral Fluid Program 2023/24"),
    S("Cannabis","cannabinoide",["weed","herbe","beuh","shit","haschich","marijuana","joint"],[4,3*D],[D,3*D],[4,2*D],"Salive : usage ponctuel ~24 h, usage lourd jusqu'à ~72 h. Urine usage régulier jusqu'à ~30 j. Cutoff salive SAMHSA 4 ng/mL.",true,"Verstraete 2004, Ther Drug Monit (oral fluid 5–48 h) · SAMHSA Oral Fluid Program 2023/24"),
    S("Delta-9 THC","cannabinoide",["thc","delta-9"],[4,3*D],[D,3*D],[4,2*D],"Identique au cannabis.",true,"Verstraete 2004, Ther Drug Monit (oral fluid 5–48 h) · SAMHSA Oral Fluid Program 2023/24"),
    S("HHC","cannabinoide",["hexahydrocannabinol"],[4,2*D],[D,3*D],[4,2*D],"Profil proche du THC, données limitées.",true,"Verstraete 2004, Ther Drug Monit (oral fluid 5–48 h) · SAMHSA Oral Fluid Program 2023/24"),
    S("THCP","cannabinoide",["thcp"],[6,4*D],[D,4*D],[6,3*D],"Très lipophile, fenêtre potentiellement plus longue.",true,"Verstraete 2004, Ther Drug Monit (oral fluid 5–48 h) · SAMHSA Oral Fluid Program 2023/24"),
    S("Cocaïne","stimulant",["coke","cocaine","neige","blow","charlie"],[1,2*D],[12,4*D],[4,2*D],"Salive ~1–2 j (consensus 12–48 h). Urine (benzoylecgonine) 1–4 j, usage lourd ~1 sem. Cheveux : plusieurs mois. NB : « semaines » = cheveux/urine, PAS salive.",true,"Verstraete 2004, Ther Drug Monit (oral fluid 5–48 h) · SAMHSA Oral Fluid Program 2023/24"),
    S("Amphétamine","stimulant",["speed","poudre","base"],[4,2*D],[D,4*D],[12,2*D],"Salive jusqu'à ~48 h. Urine 1–3 j.",true,"Verstraete 2004, Ther Drug Monit (oral fluid 5–48 h) · SAMHSA Oral Fluid Program 2023/24"),
    S("Méthamphétamine","stimulant",["crystal meth","ice","tina","meth"],[4,50],[D,4*D],[12,2*D],"Salive jusqu'à ~50 h (étude contrôlée Verstraete). Urine 1–4 j, plus en usage chronique.",true,"Verstraete 2004, Ther Drug Monit (oral fluid 5–48 h) · SAMHSA Oral Fluid Program 2023/24"),
    S("MDMA","empathogene",["ecstasy","ecsta","molly","xtc","pilule"],[0.5,2*D],[D,3*D],[6,2*D],"Salive ~24–48 h. Urine 1–3 j ; doses élevées plus long.",true,"Verstraete 2004, Ther Drug Monit (oral fluid 5–48 h) · SAMHSA Oral Fluid Program 2023/24"),
    S("Méphédrone","empathogene",["mephedrone","4-mmc","mcat","drone"],[2,2*D],[D,4*D],[6,2*D],"Cathinone, profil proche MDMA.",true,"Verstraete 2004, Ther Drug Monit (oral fluid 5–48 h) · SAMHSA Oral Fluid Program 2023/24"),
    S("3-MMC","empathogene",["3mmc"],[2,2*D],[D,4*D],[6,2*D],"Cathinone de synthèse.",true,"Verstraete 2004, Ther Drug Monit (oral fluid 5–48 h) · SAMHSA Oral Fluid Program 2023/24"),
    S("MDPV","stimulant",["bath salts","sels de bain"],[2,D],[D,3*D],[6,2*D],"Cathinone, données limitées.",true,"Verstraete 2004, Ther Drug Monit (oral fluid 5–48 h) · SAMHSA Oral Fluid Program 2023/24"),
    S("Méthylphénidate","stimulant",["ritalin","concerta"],[2,2*D],[D,2*D],[4,D],"Urine 1–2 j.",true,"Verstraete 2004, Ther Drug Monit (oral fluid 5–48 h) · SAMHSA Oral Fluid Program 2023/24"),
    S("Lisdexamfétamine","stimulant",["vyvanse","elvanse"],[4,2*D],[D,3*D],[12,2*D],"Métabolisé en d-amphétamine.",true,"Verstraete 2004, Ther Drug Monit (oral fluid 5–48 h) · SAMHSA Oral Fluid Program 2023/24"),
    S("Modafinil","nootropique",["provigil","modiodal"],[4,2*D],[D,2*D],[12,2*D],"Nécessite un panel spécifique.",true,"Verstraete 2004, Ther Drug Monit (oral fluid 5–48 h) · SAMHSA Oral Fluid Program 2023/24"),
    S("Héroïne","opioide",["heroin","smack","brown","came"],[2,36],[D,3*D],[2,D],"6-MAM (spécifique) très bref ; morphine en salive ~24–36 h, urine 1–3 j.",true,"Verstraete 2004, Ther Drug Monit (oral fluid 5–48 h) · SAMHSA Oral Fluid Program 2023/24"),
    S("Morphine","opioide",["morphine","skenan"],[2,36],[D,3*D],[4,D],"Opiacés en salive ~ jusqu'à 24–36 h. Urine 1–3 j.",true,"Verstraete 2004, Ther Drug Monit (oral fluid 5–48 h) · SAMHSA Oral Fluid Program 2023/24"),
    S("Codéine","opioide",["codeine","dafalgan codéiné"],[2,36],[D,3*D],[4,D],"Urine 1–3 j.",true,"Verstraete 2004, Ther Drug Monit (oral fluid 5–48 h) · SAMHSA Oral Fluid Program 2023/24"),
    S("Tramadol","opioide",["tramal","contramal","topalgic"],[4,2*D],[D,4*D],[4,2*D],"Souvent hors panel standard.",true,"Verstraete 2004, Ther Drug Monit (oral fluid 5–48 h) · SAMHSA Oral Fluid Program 2023/24"),
    S("Fentanyl","opioide",["fentanil"],[2,2*D],[D,3*D],[2,D],"Souvent absent des kits standards.",true,"Verstraete 2004, Ther Drug Monit (oral fluid 5–48 h) · SAMHSA Oral Fluid Program 2023/24"),
    S("Méthadone","opioide",["methadone"],[4,10*D],[3*D,10*D],[D,5*D],"Demi-vie longue : urine 3–10 j.",true,"Verstraete 2004, Ther Drug Monit (oral fluid 5–48 h) · SAMHSA Oral Fluid Program 2023/24"),
    S("Buprénorphine","opioide",["subutex","suboxone"],[4,3*D],[D,7*D],[4,4*D],"Urine jusqu'à ~7 j (panel dédié).",true,"Verstraete 2004, Ther Drug Monit (oral fluid 5–48 h) · SAMHSA Oral Fluid Program 2023/24"),
    S("Hydrocodone","opioide",["vicodin","norco"],[2,36],[D,3*D],[4,D],"Urine 1–3 j.",true,"Verstraete 2004, Ther Drug Monit (oral fluid 5–48 h) · SAMHSA Oral Fluid Program 2023/24"),
    S("Hydromorphone","opioide",["dilaudid","sophidone"],[2,D],[D,3*D],[4,D],"Urine 1–3 j.",true,"Verstraete 2004, Ther Drug Monit (oral fluid 5–48 h) · SAMHSA Oral Fluid Program 2023/24"),
    S("Oxycodone","opioide",["oxycontin","oxynorm","percocet"],[2,36],[D,3*D],[4,D],"Panel opiacé étendu requis.",true,"Verstraete 2004, Ther Drug Monit (oral fluid 5–48 h) · SAMHSA Oral Fluid Program 2023/24"),
    S("Alprazolam","depresseur",["xanax"],[4,26],[D,4*D],[12,2*D],"Benzo courte : urine 1–4 j.",true,"Verstraete 2004, Ther Drug Monit (oral fluid 5–48 h) · SAMHSA Oral Fluid Program 2023/24"),
    S("Diazépam","depresseur",["valium","diazepam"],[4,10*D],[3*D,30*D],[D,10*D],"Nordazépam : urine jusqu'à ~30 j (usage régulier).",true,"Verstraete 2004, Ther Drug Monit (oral fluid 5–48 h) · SAMHSA Oral Fluid Program 2023/24"),
    S("Clonazépam","depresseur",["clonazepam","rivotril","klonopin"],[4,2*D],[3*D,10*D],[D,5*D],"Métabolites lents.",true,"Verstraete 2004, Ther Drug Monit (oral fluid 5–48 h) · SAMHSA Oral Fluid Program 2023/24"),
    S("Lorazépam","depresseur",["lorazepam","ativan","temesta"],[4,36],[D,4*D],[12,2*D],"Urine 1–4 j.",true,"Verstraete 2004, Ther Drug Monit (oral fluid 5–48 h) · SAMHSA Oral Fluid Program 2023/24"),
    S("Bromazépam","depresseur",["lexomil","lexotan"],[4,2*D],[2*D,5*D],[12,3*D],"Urine 2–5 j.",true,"Verstraete 2004, Ther Drug Monit (oral fluid 5–48 h) · SAMHSA Oral Fluid Program 2023/24"),
    S("Zolpidem","depresseur",["stilnox","ambien"],[2,D],[D,2*D],[4,D],"Hors panel standard.",true,"Verstraete 2004, Ther Drug Monit (oral fluid 5–48 h) · SAMHSA Oral Fluid Program 2023/24"),
    S("Zopiclone","depresseur",["imovane"],[2,D],[D,2*D],[4,D],"Hors panel standard.",true,"Verstraete 2004, Ther Drug Monit (oral fluid 5–48 h) · SAMHSA Oral Fluid Program 2023/24"),
    S("Prégabaline","depresseur",["lyrica"],[2,D],[D,2*D],[4,2*D],"Panel spécifique requis.",true,"Verstraete 2004, Ther Drug Monit (oral fluid 5–48 h) · SAMHSA Oral Fluid Program 2023/24"),
    S("Gabapentine","depresseur",["neurontin"],[2,D],[D,2*D],[4,2*D],"Panel spécifique requis.",true,"Verstraete 2004, Ther Drug Monit (oral fluid 5–48 h) · SAMHSA Oral Fluid Program 2023/24"),
    S("Clonazolam","depresseur",["clonazolam"],[4,3*D],[4*D,14*D],[2*D,7*D],"Designer-benzo, demi-vie longue.",true,"Verstraete 2004, Ther Drug Monit (oral fluid 5–48 h) · SAMHSA Oral Fluid Program 2023/24"),
    S("Flubromazolam","depresseur",["flubro"],[4,4*D],[4*D,14*D],[2*D,7*D],"Demi-vie très longue.",true,"Verstraete 2004, Ther Drug Monit (oral fluid 5–48 h) · SAMHSA Oral Fluid Program 2023/24"),
    S("Étizolam","depresseur",["etizolam","etilaam"],[4,2*D],[D,4*D],[12,2*D],"Urine 1–4 j.",true,"Verstraete 2004, Ther Drug Monit (oral fluid 5–48 h) · SAMHSA Oral Fluid Program 2023/24"),
    S("Kétamine","dissociatif",["ketamine","ket","keta","spéciale k"],[4,D],[D,3*D],[4,2*D],"Panel spécifique requis.",true,"Verstraete 2004, Ther Drug Monit (oral fluid 5–48 h) · SAMHSA Oral Fluid Program 2023/24"),
    S("2-FDCK","dissociatif",["2-fdck","2f-dck"],[4,D],[D,3*D],[4,2*D],"Profil estimé proche kétamine.",true,"Verstraete 2004, Ther Drug Monit (oral fluid 5–48 h) · SAMHSA Oral Fluid Program 2023/24"),
    S("PCP","dissociatif",["angel dust","phencyclidine"],[4,3*D],[3*D,7*D],[4,2*D],"Urine 3–7 j (chronique plus).",true,"Verstraete 2004, Ther Drug Monit (oral fluid 5–48 h) · SAMHSA Oral Fluid Program 2023/24"),
    S("DXM","dissociatif",["dextromethorphane","robitussin","dextrométhorphane"],[2,2*D],[D,2*D],[4,2*D],"Hors panel standard.",true,"Verstraete 2004, Ther Drug Monit (oral fluid 5–48 h) · SAMHSA Oral Fluid Program 2023/24"),
    S("GHB","depresseur",["ghb","liquid ecstasy"],[0,6],[4,12],[2,8],"Clairance ultra-rapide : quelques heures.",true,"Verstraete 2004, Ther Drug Monit (oral fluid 5–48 h) · SAMHSA Oral Fluid Program 2023/24"),
    S("GBL","depresseur",["gbl","gamma-butyrolactone"],[0,6],[4,12],[2,8],"Prodrogue du GHB, même fenêtre.",true,"Verstraete 2004, Ther Drug Monit (oral fluid 5–48 h) · SAMHSA Oral Fluid Program 2023/24"),
    S("LSD","psychedelique",["acide","acid","buvard","trip"],[0,12],[8,3*D],[2,12],"LC-MS sensible requis, souvent hors panel.",true,"Verstraete 2004, Ther Drug Monit (oral fluid 5–48 h) · SAMHSA Oral Fluid Program 2023/24"),
    S("Psilocybine","psychedelique",["champignons","shrooms","truffes","champis"],[0,12],[4,D],[2,12],"Psilocine brève, rarement ciblée.",true,"Verstraete 2004, Ther Drug Monit (oral fluid 5–48 h) · SAMHSA Oral Fluid Program 2023/24"),
    S("DMT","psychedelique",["dimethyltryptamine","diméthyltryptamine"],[0,4],[0,D],[0,4],"Demi-vie très courte, non ciblé en routine.",false,"Verstraete 2004, Ther Drug Monit (oral fluid 5–48 h) · SAMHSA Oral Fluid Program 2023/24"),
    S("2C-B","psychedelique",["nexus","bees"],[2,D],[12,2*D],[4,D],"Estimé 1–2 j en urine.",true,"Verstraete 2004, Ther Drug Monit (oral fluid 5–48 h) · SAMHSA Oral Fluid Program 2023/24"),
    S("Mescaline","psychedelique",["peyote","san pedro"],[4,D],[D,4*D],[4,2*D],"Urine 1–4 j.",true,"Verstraete 2004, Ther Drug Monit (oral fluid 5–48 h) · SAMHSA Oral Fluid Program 2023/24"),
    S("Ibogaïne","psychedelique",["ibogaine","iboga"],[4,2*D],[D,4*D],[12,2*D],"Données limitées.",true,"Verstraete 2004, Ther Drug Monit (oral fluid 5–48 h) · SAMHSA Oral Fluid Program 2023/24"),
    S("Kratom","opioide",["mitragynine"],[4,2*D],[D,5*D],[4,2*D],"Panel spécifique requis.",true,"Verstraete 2004, Ther Drug Monit (oral fluid 5–48 h) · SAMHSA Oral Fluid Program 2023/24"),
    S("Modérateur — Quétiapine","depresseur",["seroquel","quetiapine","quétiapine","xeroquel"],[4,D],[D,2*D],[4,D],"Antipsychotique, hors panel standard.",true,"Verstraete 2004, Ther Drug Monit (oral fluid 5–48 h) · SAMHSA Oral Fluid Program 2023/24"),
    S("Tianeptine","nootropique",["stablon"],[2,D],[12,2*D],[4,D],"Données limitées.",true,"Verstraete 2004, Ther Drug Monit (oral fluid 5–48 h) · SAMHSA Oral Fluid Program 2023/24"),
    S("Phénibut","nootropique",["phenibut","noofen"],[2,2*D],[D,4*D],[12,2*D],"Estimation.",true,"Verstraete 2004, Ther Drug Monit (oral fluid 5–48 h) · SAMHSA Oral Fluid Program 2023/24"),
    S("Naloxone","opioide",["narcan","prenoxad"],[0,4],[4,D],[0,6],"Antagoniste, fenêtre courte.",true,"Verstraete 2004, Ther Drug Monit (oral fluid 5–48 h) · SAMHSA Oral Fluid Program 2023/24"),
    S("Nicotine","stimulant",["tabac","cigarette","clope","vape","puff","snus","iqos","chicha"],[0.5,4],[D,4*D],[12,3*D],"La cotinine (urine) tient 3–4 j (gros fumeur : plus).",true,"Verstraete 2004, Ther Drug Monit (oral fluid 5–48 h) · SAMHSA Oral Fluid Program 2023/24"),
    S("Paracétamol","autre",["doliprane","efferalgan","tylenol","acetaminophene"],[0,12],[0,D],[0,12],"Non ciblé par les tests de dépistage.",false,"Verstraete 2004, Ther Drug Monit (oral fluid 5–48 h) · SAMHSA Oral Fluid Program 2023/24"),
    S("Ibuprofène","autre",["advil","nurofen"],[0,12],[0,D],[0,12],"Non ciblé.",false,"Verstraete 2004, Ther Drug Monit (oral fluid 5–48 h) · SAMHSA Oral Fluid Program 2023/24"),
    S("Caféine","stimulant",["caffeine","café","cafe"],[0,6],[0,D],[0,12],"Non ciblé par les tests de dépistage.",false,"Verstraete 2004, Ther Drug Monit (oral fluid 5–48 h) · SAMHSA Oral Fluid Program 2023/24"),
    S("Protoxyde d'azote","dissociatif",["n2o","gaz hilarant","ballons","proto"],[0,1],[0,1],[0,1],"Élimination en minutes, non ciblé.",false,"Verstraete 2004, Ther Drug Monit (oral fluid 5–48 h) · SAMHSA Oral Fluid Program 2023/24"),
    S("Poppers","inhalant",["poppers","nitrite","amyl","amyle","rush","jungle juice","liquid gold","nitrite d'alkyle"],[0,1],[0,2],[0,2],"Nitrites d'alkyle : NON détectés par les tests salivaires/urinaires de routine (métabolisme en minutes). Risque réel = méthémoglobinémie (surtout si AVALÉ), jamais avec Viagra/Cialis.",false,"NIDA Inhalants ; case reports méthémoglobinémie"),
    S("Solvants volatils","inhalant",["colle","toluène","toluene","sniff colle","trichloréthylène","solvant"],[0,2],[0,12],[0,12],"Solvants volatils : non ciblés par les tests usuels (panels spécialisés seulement). Risque = mort subite par sniffing (arythmie) dès la 1re fois ; hypoxie.",false,"NIDA Inhalants ; case reports méthémoglobinémie"),
    S("Butane / gaz","inhalant",["butane","propane","gaz briquet","gaz","aérosol"],[0,1],[0,4],[0,4],"Gaz (butane/propane) : non détectés en routine. Risque = mort subite par sniffing, asphyxie, gelures des voies aériennes.",false,"NIDA Inhalants ; case reports méthémoglobinémie"),
    S("Éther diéthylique","inhalant",["éther","ether","diéthyléther"],[0,2],[0,12],[0,12],"Éther : hors panels standards. Très inflammable. Dépression respiratoire, perte de conscience rapide.",false,"NIDA Inhalants ; case reports méthémoglobinémie"),
  ];
  global.MD_DETECTION = DETECTION;
  global.MD_DETECTION_DISCLAIMER = DISCLAIMER;
})(window);
