/* ============================================================================
   MyDope Off — core.js  (socle partagé unique)
   Remplace les 6 copies inline de LUCIDE et corrige :
     • CRITIQUE-2 : l'identité (prénom/âge) ne transite PLUS par l'URL
       (profil lu uniquement dans localStorage) → plus de fuite via Referer.
     • MAJEUR-1 : une seule source pour nav / logo / i18n / région.

   Dépendances optionnelles, chargées AVANT core.js si présentes :
     i18n.js     -> window.MD_DICT          (dictionnaire de l'UI)
     regions.js  -> window.MDRegions        (données régionalisées)
   Dégrade proprement si absentes.

   Ordre conseillé dans chaque page :
     <link rel="stylesheet" href="assets/css/tokens.css">
     <script src="assets/js/i18n.js"></script>
     <script src="assets/js/regions.js"></script>
     <script src="assets/js/core.js"></script>
     <script> MDCore.init({ page:'index' }); </script>
   ============================================================================ */
window.MDCore = (function () {
  'use strict';

  var KEY = 'ctc_v6';
  var LANG_KEY = 'mydopeoff_lang';
  var LANGS = ['fr', 'en', 'es', 'de'];
  var LANG_NAMES = { fr:'Français', en:'English', es:'Español', de:'Deutsch' };

  /* ---------- Profil (localStorage uniquement — jamais l'URL) ---------- */
  function store(){ try { return JSON.parse(localStorage.getItem(KEY)) || {}; } catch (e){ return {}; } }
  function user(){ return store().user || null; }
  function saveUser(u){
    try { var s = store(); s.user = u; localStorage.setItem(KEY, JSON.stringify(s)); } catch (e){}
  }
  function regionCode(){
    var u = user();
    var c = (u && u.region) || 'BE';
    if (window.MDRegions && !window.MDRegions.exists(c)) c = 'BE';
    return c;
  }
  function region(){ return window.MDRegions ? window.MDRegions.get(regionCode()) : null; }

  /* ---------- Liens : INCHANGÉS (aucune donnée personnelle ajoutée) ---------- */
  function link(href){ return href; }

  /* ---------- i18n ---------- */
  function dict(){ return window.MD_DICT || (window.LUCIDE && window.LUCIDE.DICT) || {}; }
  function lang(){
    try { var l = localStorage.getItem(LANG_KEY); if (l && LANGS.indexOf(l) > -1) return l; } catch (e){}
    return 'fr';
  }
  function setLang(l){
    if (LANGS.indexOf(l) === -1) return;
    try { localStorage.setItem(LANG_KEY, l); } catch (e){}
    document.documentElement.setAttribute('lang', l);
    applyI18n();
    document.dispatchEvent(new CustomEvent('langchange', { detail:{ lang:l } }));
  }
  function t(keyOrObj, vars){
    var l = lang(), s, D = dict();
    if (keyOrObj && typeof keyOrObj === 'object') s = keyOrObj[l] || keyOrObj.fr || '';
    else { var e = D[keyOrObj]; s = e ? (e[l] || e.fr) : keyOrObj; }
    if (vars) Object.keys(vars).forEach(function (k){ s = s.replace('{' + k + '}', vars[k]); });
    return s;
  }
  // data-i18n => textContent (sûr) ; data-i18n-html réservé à une liste blanche.
  var HTML_OK = { 'sout.hero_title':1, 'home.disclaimer_strong':1 };
  function applyI18n(){
    var D = dict();
    document.querySelectorAll('[data-i18n]').forEach(function (el){
      var k = el.getAttribute('data-i18n'); if (D[k]) el.textContent = t(k);
    });
    document.querySelectorAll('[data-i18n-html]').forEach(function (el){
      var k = el.getAttribute('data-i18n-html'); if (D[k] && HTML_OK[k]) el.innerHTML = t(k);
    });
    document.querySelectorAll('[data-i18n-ph]').forEach(function (el){
      var k = el.getAttribute('data-i18n-ph'); if (D[k]) el.setAttribute('placeholder', t(k));
    });
    document.querySelectorAll('[data-i18n-aria]').forEach(function (el){
      var k = el.getAttribute('data-i18n-aria'); if (D[k]) el.setAttribute('aria-label', t(k));
    });
    var nav = document.querySelector('.bottom-nav[data-page]');
    if (nav) nav.outerHTML = renderNav(nav.getAttribute('data-page') || '');
  }
  function renderLangSelect(){
    document.querySelectorAll('[data-langselect]').forEach(function (host){
      var cur = lang();
      host.innerHTML = '<div class="lang-select" role="group" aria-label="' + t('common.language') + '">' +
        LANGS.map(function (l){
          return '<button type="button" class="lang-btn' + (l === cur ? ' on' : '') +
            '" data-setlang="' + l + '" aria-pressed="' + (l === cur) + '">' + l.toUpperCase() + '</button>';
        }).join('') + '</div>';
      host.querySelectorAll('[data-setlang]').forEach(function (b){
        b.addEventListener('click', function (){ setLang(b.getAttribute('data-setlang')); renderLangSelect(); });
      });
    });
  }

  /* ---------- Marque / logo ---------- */
  function logoSVG(size, mono){
    size = size || 32;
    var ring = mono ? '#fff' : '#2563EB', bar = mono ? '#fff' : '#0F172A';
    return '<svg viewBox="0 0 48 48" width="' + size + '" height="' + size + '" fill="none" role="img" aria-label="MyDope Off">' +
      '<path d="M15.2 13.6a14 14 0 1 0 17.6 0" stroke="' + ring + '" stroke-width="5" stroke-linecap="round"/>' +
      '<line x1="24" y1="6" x2="24" y2="22" stroke="' + bar + '" stroke-width="5" stroke-linecap="round"/></svg>';
  }
  function appIcon(size){
    size = size || 56;
    return '<span class="app-icon" style="width:' + size + 'px;height:' + size + 'px;border-radius:' +
      Math.round(size * 0.28) + 'px;">' + logoSVG(Math.round(size * 0.56), true) + '</span>';
  }
  function wordmark(){ return '<span class="wordmark">MyDope <b>Off</b></span>'; }

  /* ---------- Navigation ---------- */
  var NAV = [
    { k:'index',         href:'index.html',         tkey:'nav.home',       icon:'<path d="M3 9l9-7 9 7v11a2 2 0 01-2 2H5a2 2 0 01-2-2z"/><polyline points="9 22 9 12 15 12 15 22"/>' },
    { k:'suivi',         href:'suivi.html',         tkey:'nav.tracking',   icon:'<path d="M22 7L13.5 15.5 8.5 10.5 2 17"/><polyline points="16 7 22 7 22 13"/>' },
    { k:'psychochecker', href:'psychochecker.html', tkey:'nav.substances', icon:'<circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/>' },
    { k:'fiches',        href:'fiches.html',        tkey:'nav.protocols',  icon:'<path d="M22 12h-4l-3 9L9 3l-3 9H2"/>' },
    { k:'rdr',           href:'rdr.html',           tkey:'nav.rdr',        icon:'<path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/>' }
  ];
  function renderNav(active){
    return '<nav class="bottom-nav" data-page="' + (active || '') + '" aria-label="Navigation principale">' +
      NAV.map(function (n){
        return '<a class="bn-item' + (n.k === active ? ' active on' : '') + '" href="' + link(n.href) + '"' +
          (n.k === active ? ' aria-current="page"' : '') + '>' +
          '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">' +
          n.icon + '</svg><span>' + t(n.tkey) + '</span></a>';
      }).join('') + '</nav>';
  }

  /* ---------- Init ---------- */
  function init(opts){
    opts = opts || {};
    document.documentElement.setAttribute('lang', lang());

    document.querySelectorAll('[data-logo]').forEach(function (el){
      el.innerHTML = logoSVG(parseInt(el.getAttribute('data-logo'), 10) || 32, el.hasAttribute('data-mono'));
    });
    document.querySelectorAll('[data-appicon]').forEach(function (el){
      el.innerHTML = appIcon(parseInt(el.getAttribute('data-appicon'), 10) || 56);
    });
    document.querySelectorAll('[data-wordmark]').forEach(function (el){ el.innerHTML = wordmark(); });

    var navHost = document.querySelector('[data-nav]');
    if (navHost) navHost.outerHTML = renderNav(opts.page || '');

    // Liens nus (aucun ?name=) — corrige la fuite de données
    document.querySelectorAll('[data-go]').forEach(function (a){ a.setAttribute('href', a.getAttribute('data-go')); });

    document.querySelectorAll('[data-back]').forEach(function (b){
      b.addEventListener('click', function (){
        if (window.history.length > 1 && document.referrer && document.referrer.indexOf(location.origin) === 0) window.history.back();
        else location.href = 'index.html';
      });
    });

    applyI18n();
    renderLangSelect();

    if ('serviceWorker' in navigator) navigator.serviceWorker.register('./sw.js').catch(function (){});
  }

  return {
    user:user, saveUser:saveUser, region:region, regionCode:regionCode,
    link:link, t:t, lang:lang, setLang:setLang, applyI18n:applyI18n, renderLangSelect:renderLangSelect,
    logoSVG:logoSVG, appIcon:appIcon, wordmark:wordmark, renderNav:renderNav, init:init,
    LANGS:LANGS, LANG_NAMES:LANG_NAMES
  };
})();
/* Alias de compatibilité pendant la migration (pages encore en LUCIDE.*) */
if (!window.LUCIDE) window.LUCIDE = window.MDCore;
