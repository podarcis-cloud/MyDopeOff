/* MyDope Off — logique de page : inscription.html (externalisée pour CSP script-src 'self') */
(function(){
  var T = {
    'reg.age_hint':{fr:"Optionnel — sert seulement à adapter l'affichage.",en:'Optional — only used to tailor the display.',es:'Opcional — solo para adaptar la vista.',de:'Optional — nur zur Anzeige.'},
    'reg.consent':{fr:"Outil d'information et de réduction des risques. Il n'encourage pas l'usage et ne remplace pas un avis médical. Quel que soit ton âge, tu peux aussi parler à une personne de confiance ou à un service d'aide. Urgence : 112 / 15.",en:'An information and harm-reduction tool. It does not encourage use and is not a substitute for medical advice. Whatever your age, you can also talk to someone you trust or a support service. Emergency: 112 / 15.',es:'Herramienta de información y reducción de riesgos. No fomenta el consumo ni sustituye el consejo médico. Sea cual sea tu edad, también puedes hablar con alguien de confianza o un servicio de ayuda. Urgencia: 112 / 15.',de:'Ein Informations- und Risikominderungs-Tool. Es fördert keinen Konsum und ersetzt keine ärztliche Beratung. Egal wie alt du bist, sprich auch mit einer Vertrauensperson oder Hilfestelle. Notruf: 112 / 15.'},
    'reg.save':{fr:'Enregistrer',en:'Save',es:'Guardar',de:'Speichern'}
  };
  window.MD_DICT = window.MD_DICT || {};
  Object.keys(T).forEach(function(k){ if(!window.MD_DICT[k]) window.MD_DICT[k]=T[k]; });
})();

// Remplir le sélecteur de région depuis regions.js (source unique)
(function(){
  var sel = document.getElementById('f-region');
  sel.innerHTML = MDRegions.list().map(function(r){
    return '<option value="'+r.code+'">'+r.flag+' '+r.label+'</option>';
  }).join('');
})();

MDCore.init({ page:'' });

var nameI = document.getElementById('f-name');
var ageI  = document.getElementById('f-age');
var regI  = document.getElementById('f-region');
var goBtn = document.getElementById('f-go');
var cancel= document.getElementById('f-cancel');

function refresh(){ goBtn.disabled = nameI.value.trim().length === 0; }
nameI.addEventListener('input', refresh);
nameI.addEventListener('keydown', function(e){ if(e.key==='Enter' && nameI.value.trim()) doSave(); });

function doSave(){
  var name = nameI.value.trim(); if(!name) return;
  // Profil enregistré UNIQUEMENT en local — jamais dans l'URL.
  MDCore.saveUser({ name:name, age:ageI.value.trim(), region:regI.value });
  location.href = 'index.html';
}
goBtn.addEventListener('click', doSave);
cancel.addEventListener('click', function(){ location.href='index.html'; });

// Mode "modifier mes infos" si un profil existe déjà
(function(){
  var u = MDCore.user();
  if(u && u.name){
    nameI.value = u.name; ageI.value = u.age || ''; regI.value = (u.region||'BE');
    goBtn.disabled = false; goBtn.textContent = MDCore.t('reg.save');
    cancel.style.display = 'block';
  }
})();
