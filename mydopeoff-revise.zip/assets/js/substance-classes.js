/* ============================================================================
   MyDope Off — substance-classes.js
   Filet de sécurité par classe pour les 270 fiches (≈36 000 paires possibles).

   Table AUDITABLE : chaque fiche -> classes pharmacologiques.
   Dérivée des catégories existantes + corrections de sécurité :
     • thiénodiazépines (étizolam…) -> dépresseur   (échappaient au regex 'benzo')
     • IRSNA (tramadol…) & 5-HTP    -> sérotoninergique (syndrome sérotoninergique)
     • antipsychotique / alpha-2 / anxiolytique / antiépileptique / myorelaxant -> dépresseur
     • synthétiques 'noid'          -> cannabinoïde
     • antihistaminique             -> anticholinergique
   8 fiches sans classe (bénignes) tombent volontairement en 'caution' (jaune) :
     Ibuprofène, Paracétamol, Mélatonine, Noopept, Oxiracétam, Piracétam,
     Pramiracétam, Aniracétam.

   À FAIRE VALIDER par un·e addictologue/pharmacien·ne. Édition = 1 seul endroit.

   BRANCHEMENT (après interactions-fix.js) :
     <script src="interactions-fix.js"></script>
     <script src="interactions-data.js"></script>
     <script src="substance-classes.js"></script>
   ========================================================================== */
(function (global) {
  'use strict';

  // Classes par nom de fiche (clé = nom français exact, comme addSub).
  var CLASSES = {
    "1,4-Butanediol": ["dépresseur"],
    "10-OH-HHC": ["cannabinoïde"],
    "1cP-LSD": ["sérotoninergique"],
    "1P-LSD": ["sérotoninergique"],
    "2-FA": ["stimulant", "sérotoninergique"],
    "2-FDCK": ["dissociatif"],
    "2-FEA": ["stimulant", "sérotoninergique"],
    "2-FMA": ["stimulant", "sérotoninergique"],
    "2-FMA": ["stimulant", "sérotoninergique"],
    "2-MMC": ["stimulant", "sérotoninergique"],
    "25B-NBOH": ["sérotoninergique"],
    "25B-NBOMe": ["sérotoninergique"],
    "25C-NBOMe": ["sérotoninergique"],
    "25I-NBOMe": ["sérotoninergique"],
    "2C-B": ["sérotoninergique"],
    "2C-C": ["sérotoninergique"],
    "2C-D": ["sérotoninergique"],
    "2C-E": ["sérotoninergique"],
    "2C-H": ["sérotoninergique"],
    "2C-I": ["sérotoninergique"],
    "2C-P": ["sérotoninergique"],
    "2C-T-2": ["sérotoninergique"],
    "2C-T-2": ["sérotoninergique"],
    "2C-T-4": ["sérotoninergique"],
    "2C-T-7": ["sérotoninergique"],
    "2C-T-7": ["sérotoninergique"],
    "2M2B": ["dépresseur"],
    "3-CMC": ["stimulant", "sérotoninergique"],
    "3-FA": ["stimulant", "sérotoninergique"],
    "3-FEA": ["stimulant", "sérotoninergique"],
    "3-FMA": ["stimulant", "sérotoninergique"],
    "3-FPM": ["stimulant", "sérotoninergique"],
    "3-HO-PCE": ["dissociatif", "opioïde"],
    "3-HO-PCP": ["dissociatif", "opioïde"],
    "3-MEC": ["stimulant", "sérotoninergique"],
    "3-MeO-PCE": ["dissociatif"],
    "3-MeO-PCMo": ["dissociatif"],
    "3-MeO-PCP": ["dissociatif"],
    "3-MMC": ["stimulant", "sérotoninergique"],
    "3C-E": ["sérotoninergique"],
    "4-AcO-DET": ["sérotoninergique"],
    "4-AcO-DiPT": ["sérotoninergique"],
    "4-AcO-DMT": ["sérotoninergique"],
    "4-AcO-MET": ["sérotoninergique"],
    "4-AcO-MiPT": ["sérotoninergique"],
    "4-CMC": ["stimulant", "sérotoninergique"],
    "4-FA": ["stimulant", "sérotoninergique"],
    "4-FMA": ["stimulant", "sérotoninergique"],
    "4-HO-MET": ["sérotoninergique"],
    "4-HO-MiPT": ["sérotoninergique"],
    "4F-MDMB-BICA": ["cannabinoïde"],
    "5-APB": ["stimulant", "sérotoninergique"],
    "5-HTP": ["sérotoninergique"],
    "5-MeO-DiPT": ["sérotoninergique"],
    "5-MeO-DMT (synthétique)": ["sérotoninergique"],
    "5-MeO-MiPT": ["sérotoninergique"],
    "5F-ADB": ["cannabinoïde"],
    "6-APB": ["stimulant", "sérotoninergique"],
    "6-APDB": ["sérotoninergique"],
    "AB-CHMINACA": ["cannabinoïde"],
    "AB-FUBINACA": ["cannabinoïde"],
    "Absinthe / Armoise": ["dépresseur"],
    "Acétylfentanyl": ["opioïde"],
    "ADB-4en-PINACA": ["cannabinoïde"],
    "ADB-BUTINACA": ["cannabinoïde"],
    "Adrafinil": ["stimulant", "sérotoninergique"],
    "Alcool": ["dépresseur"],
    "Allylescaline": ["sérotoninergique"],
    "Alpha-PHiP": ["stimulant", "sérotoninergique"],
    "Alpha-PHP": ["stimulant", "sérotoninergique"],
    "Alpha-PVP": ["stimulant", "sérotoninergique"],
    "Alprazolam": ["dépresseur"],
    "AM-2201": ["cannabinoïde"],
    "Amphétamine": ["stimulant", "sérotoninergique"],
    "AMT": ["sérotoninergique"],
    "Aniracétam": [],
    "Armodafinil": ["stimulant", "sérotoninergique"],
    "Ayahuasca": ["imao", "sérotoninergique"],
    "Belladone": ["anticholinergique"],
    "Bromazolam": ["dépresseur"],
    "Bromazépam": ["dépresseur"],
    "Bufoténine": ["sérotoninergique"],
    "Buprenorphine": ["opioïde"],
    "Butylone": ["stimulant", "sérotoninergique"],
    "Bétel": ["stimulant", "sérotoninergique"],
    "Caféine": ["stimulant", "sérotoninergique"],
    "Cannabis": ["cannabinoïde"],
    "Cannabis CBD": ["cannabinoïde"],
    "Carfentanil": ["opioïde"],
    "Carisoprodol": ["dépresseur"],
    "CBC": ["cannabinoïde"],
    "CBD": ["cannabinoïde"],
    "CBDP": ["cannabinoïde"],
    "CBG": ["cannabinoïde"],
    "CBN": ["cannabinoïde"],
    "Champignons Amanita muscaria": ["anticholinergique", "dépresseur"],
    "Chloral hydrate": ["dépresseur"],
    "Clonazolam": ["dépresseur"],
    "Clonazépam": ["dépresseur"],
    "Clonidine": ["dépresseur"],
    "Cocaïne": ["stimulant", "sérotoninergique"],
    "Codéine": ["opioïde"],
    "Crapaud du Colorado (5-MeO-DMT)": ["sérotoninergique"],
    "CUMYL-PEGACLONE": ["cannabinoïde"],
    "Datura": ["anticholinergique"],
    "Delta-10 THC": ["cannabinoïde"],
    "Delta-8 THC": ["cannabinoïde"],
    "Delta-9 THC": ["cannabinoïde"],
    "Deschloroetizolam": ["dépresseur"],
    "Deschlorokétamine": ["dissociatif"],
    "Desoxypipradrol": ["stimulant", "sérotoninergique"],
    "Dextrométhorphane": ["dissociatif"],
    "Dextropropoxyphène": ["opioïde"],
    "Diazépam": ["dépresseur"],
    "Diphenhydramine": ["anticholinergique"],
    "Diphenidine": ["dissociatif"],
    "DiPT": ["sérotoninergique"],
    "DMT": ["sérotoninergique"],
    "DOB": ["sérotoninergique"],
    "DOC": ["sérotoninergique"],
    "DOI": ["sérotoninergique"],
    "DOM": ["stimulant", "sérotoninergique"],
    "DOM": ["sérotoninergique"],
    "DPT": ["sérotoninergique"],
    "EPT": ["sérotoninergique"],
    "Escaline": ["sérotoninergique"],
    "ETH-CAT": ["stimulant", "sérotoninergique"],
    "ETH-LAD": ["sérotoninergique"],
    "Ethylone": ["stimulant", "sérotoninergique"],
    "Ethylphénidate": ["stimulant", "sérotoninergique"],
    "Etizolam": ["dépresseur"],
    "Eutylone": ["stimulant", "sérotoninergique"],
    "Fentanyl": ["opioïde"],
    "Flualprazolam": ["dépresseur"],
    "Flubromazolam": ["dépresseur"],
    "Flubromazépam": ["dépresseur"],
    "Gabapentine": ["dépresseur"],
    "GBL": ["dépresseur"],
    "GHB": ["dépresseur"],
    "Graines de liseron (LSA)": ["sérotoninergique"],
    "H2CBD": ["cannabinoïde"],
    "H4CBD": ["cannabinoïde"],
    "Hexen": ["stimulant", "sérotoninergique"],
    "Hexédrone": ["stimulant", "sérotoninergique"],
    "HHC": ["cannabinoïde"],
    "HHC-O": ["cannabinoïde"],
    "HHC-P": ["cannabinoïde"],
    "HHCH": ["cannabinoïde"],
    "HHCP": ["cannabinoïde"],
    "Hydrocodone": ["opioïde"],
    "Hydromorphone": ["opioïde"],
    "Hydroxyzine": ["anticholinergique", "dépresseur"],
    "Héroïne": ["opioïde"],
    "Ibogaïne": ["sérotoninergique"],
    "Ibuprofène": [],
    "Isopropylphénidate": ["stimulant", "sérotoninergique"],
    "Isotonitazène": ["opioïde"],
    "Jusquiame": ["anticholinergique"],
    "JWH-018": ["cannabinoïde"],
    "JWH-073": ["cannabinoïde"],
    "Kanna": ["dépresseur", "stimulant", "sérotoninergique"],
    "Kava": ["dépresseur"],
    "Khat": ["stimulant", "sérotoninergique"],
    "Klonopin": ["dépresseur"],
    "Kratom": ["opioïde", "stimulant", "sérotoninergique"],
    "Krokodil (désomorphine)": ["opioïde"],
    "Kétamine": ["dissociatif"],
    "Kétamine S (eskétamine)": ["dissociatif"],
    "Lisdexamfétamine": ["stimulant", "sérotoninergique"],
    "Lorazépam": ["dépresseur"],
    "Lotus bleu": ["dépresseur"],
    "LSA": ["sérotoninergique"],
    "LSD": ["sérotoninergique"],
    "LSM-775": ["sérotoninergique"],
    "LSZ": ["sérotoninergique"],
    "MCPP": ["sérotoninergique"],
    "MDA": ["stimulant", "sérotoninergique"],
    "MDAI": ["sérotoninergique"],
    "MDEA": ["stimulant", "sérotoninergique"],
    "MDMA": ["stimulant", "sérotoninergique"],
    "MDMB-4en-PINACA": ["cannabinoïde"],
    "MDPHP": ["stimulant", "sérotoninergique"],
    "MDPV": ["stimulant", "sérotoninergique"],
    "Mescaline": ["sérotoninergique"],
    "Mescaline (sulfate/HCl)": ["sérotoninergique"],
    "MET": ["sérotoninergique"],
    "Metizolam": ["dépresseur"],
    "Mexedrone": ["stimulant", "sérotoninergique"],
    "MiPT": ["sérotoninergique"],
    "Modafinil": ["stimulant", "sérotoninergique"],
    "Morphine": ["opioïde"],
    "Muscade": ["anticholinergique"],
    "Muscimol": ["dissociatif", "dépresseur"],
    "Médétomidine": ["dépresseur"],
    "Mélatonine": [],
    "Méphédrone": ["stimulant", "sérotoninergique"],
    "Méprobamate": ["dépresseur"],
    "Méthadone": ["opioïde"],
    "Méthallylescaline": ["sérotoninergique"],
    "Méthamphetamine": ["stimulant", "sérotoninergique"],
    "Méthaqualone": ["dépresseur"],
    "Méthoxphénidine": ["dissociatif"],
    "Méthoxétamine": ["dissociatif"],
    "Méthylone": ["stimulant", "sérotoninergique"],
    "Méthylphénidate": ["stimulant", "sérotoninergique"],
    "Métonitazène": ["opioïde"],
    "Naloxone": ["opioïde"],
    "Naltrexone": ["opioïde"],
    "NEP": ["stimulant", "sérotoninergique"],
    "Nicotine": ["dépresseur", "stimulant", "sérotoninergique"],
    "Nitrazépam": ["dépresseur"],
    "Nitreux": ["dissociatif", "dépresseur"],
    "Noopept": [],
    "O-DSMT": ["opioïde"],
    "O-PCE": ["dissociatif"],
    "Opium": ["opioïde"],
    "Oxiracétam": [],
    "Oxycodone": ["opioïde"],
    "Oxymorphone": ["opioïde"],
    "Paracétamol": [],
    "PCE": ["dissociatif"],
    "PCP": ["dissociatif"],
    "Pentedrone": ["stimulant", "sérotoninergique"],
    "Pentobarbital": ["dépresseur"],
    "Pentylone": ["stimulant", "sérotoninergique"],
    "Peyotl": ["sérotoninergique"],
    "Phénibut": ["dépresseur"],
    "Phénobarbital": ["dépresseur"],
    "Phénylpiracétam": ["stimulant", "sérotoninergique"],
    "Piracétam": [],
    "PMA": ["stimulant", "sérotoninergique"],
    "Pramiracétam": [],
    "Pregabaline": ["dépresseur"],
    "PRO-LAD": ["sérotoninergique"],
    "Prolintane": ["stimulant", "sérotoninergique"],
    "Prométhazine": ["anticholinergique", "dépresseur"],
    "Propofol": ["dissociatif", "dépresseur"],
    "Proscaline": ["sérotoninergique"],
    "Protonitazène": ["opioïde"],
    "Psilocine": ["sérotoninergique"],
    "Psilocybine": ["sérotoninergique"],
    "Pyrazolam": ["dépresseur"],
    "Péthidine": ["opioïde"],
    "Quétiapine": ["dépresseur"],
    "Salvia divinorum": ["dissociatif", "sérotoninergique"],
    "Secobarbital": ["dépresseur"],
    "Sels de bain (cathinones)": ["stimulant", "sérotoninergique"],
    "Sufentanil": ["opioïde"],
    "Tapentadol": ["opioïde", "sérotoninergique"],
    "THCB": ["cannabinoïde"],
    "THCH": ["cannabinoïde"],
    "THCJD": ["cannabinoïde"],
    "THCP": ["cannabinoïde"],
    "THCV": ["cannabinoïde"],
    "Theacrine": ["stimulant", "sérotoninergique"],
    "Tianeptine": ["dépresseur", "opioïde"],
    "TMA-2": ["stimulant", "sérotoninergique"],
    "TMA-6": ["stimulant", "sérotoninergique"],
    "Tramadol": ["opioïde", "sérotoninergique"],
    "Triazolam": ["dépresseur"],
    "Tusi (cocaïne rose)": ["sérotoninergique"],
    "Témazépam": ["dépresseur"],
    "Wachuma (San Pedro)": ["sérotoninergique"],
    "Xylazine": ["dépresseur"],
    "Yopo / Anadenanthera": ["sérotoninergique"],
    "Zaleplon": ["dépresseur"],
    "Zolpidem": ["dépresseur"],
    "Zopiclone": ["dépresseur"],
    "Éphédra": ["stimulant", "sérotoninergique"],
  };

  // Regex de secours pour toute substance hors table (ex. ajouts futurs).
  var RX = [
    ['opioïde',         /opioïde|opiac|nitazène|fentanyl|kratom/],
    ['dépresseur',      /benzo|thi[eé]nodiaz|barbituri|z-drug|hypnotique|gaba|dépresseur|alcool|sédatif|anxiolytique|antipsychotique|alpha-2 agoniste|pr[ée]curseur ghb|antiépileptique|myorelaxant|inhalant/],
    ['stimulant',       /stimulant|cathinone|amphét|phénidate|eugéroïque|xanthine/],
    ['imao',            /imao|harmala|ayahuasca/],
    ['sérotoninergique',/psychédélique|tryptamine|phénéthylamine|lysergamide|empathogène|entactogène|cathinone|stimulant|irsna|pr[ée]curseur sérotonine|phénylpipérazine|dox/],
    ['dissociatif',     /dissociatif|arylcyclohexylamine|diarylethylamine|anesthésique/],
    ['anticholinergique',/anticholinergique|délirant|antihistaminique|datura/],
    ['cannabinoïde',    /cannabino|noid/]
  ];
  function fromCategories(categories){
    var j=(categories||[]).join(' ').toLowerCase(), out=[];
    RX.forEach(function(r){ if(r[1].test(j)) out.push(r[0]); });
    return out;
  }

  // Résout les classes : table d'abord (audité), sinon regex sur catégories.
  function classesFor(nom, categories){
    if (nom && CLASSES[nom]) return CLASSES[nom].slice();
    return fromCategories(categories);
  }

  // Normalisation insensible aux accents/casse : évite qu'une variante d'orthographe
  // (ex. "Buprenorphine" vs "Buprénorphine") fasse silencieusement rater la table.
  function norm(x){
    return String(x||'').toLowerCase()
      .normalize('NFD').replace(/[\u0300-\u036f]/g,'')   // retire les diacritiques
      .replace(/\s+/g,' ').trim();
  }
  var BY_ID = {};
  Object.keys(CLASSES).forEach(function(nom){ BY_ID[norm(nom)] = CLASSES[nom]; });

  function classesById(id){            // id = sortie de resolveId (alias->canonique)
    var k = norm(id);
    if (k && BY_ID[k]) return BY_ID[k].slice();
    return [];                          // muet -> le moteur retombe sur le regex des catégories
  }
  function classesFor(nom, categories){
    if (nom && CLASSES[nom]) return CLASSES[nom].slice();
    return fromCategories(categories);
  }

  global.MD_SUBSTANCE_CLASSES = CLASSES;
  global.MDClasses = { classesFor: classesFor, classesById: classesById, fromCategories: fromCategories };

  // Câblage : on INJECTE getClasses dans le moteur (table auditée prioritaire,
  // repli automatique sur le regex des catégories pour tout id absent de la table).
  if (global.MDInteractions && typeof global.MDInteractions.configure === 'function') {
    global.MDInteractions.configure({ getClasses: classesById });
  }
})(window);
