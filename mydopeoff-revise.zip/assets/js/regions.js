/* ============================================================================
   MyDope Off — regions.js
   COUCHE DE DONNÉES RÉGIONALISÉE (source unique).
   Régions : BE · FR · CH · CA(QC) · LU  (+ structure prête pour US/ES/DE).

   Contient, par région :
     emergency  : numéros d'urgence + lignes d'écoute/info (tel cliquables)
     centres    : structures de soin / RDR
     groupes    : groupes d'entraide
     testing    : services d'analyse de produit (drug-checking)
     naloxone   : accès à la naloxone (anti-overdose opioïde)
     legal      : statut légal (cannabis, autres drogues, conduite, bon samaritain)
     tips       : conseils locaux

   MULTILINGUE : les numéros/URL/labels sont neutres. Les CHAÎNES descriptives
   (desc, tips, legal.summary) restent en FR (source de vérité) et sont traduites
   via window.LUCIDE_RDR_I18N (voir rdr-i18n.js), comme l'architecture existante.

   ⚠️ DONNÉES LÉGALES vérifiées 2026-06 — ELLES CHANGENT. Chaque bloc `legal`
   porte `verifie_le`. À revérifier au moins 1×/an. Information éducative,
   ne remplace pas un conseil juridique.
   Sources légales : EUDA/EMCDDA, lois nationales, panoramas 2026 (cannabis).
   ============================================================================ */
(function (global) {
  'use strict';

  // Enum de statut (l'UI peut colorer/traduire) :
  // 'illegal' | 'decriminalise' | 'tolere' | 'legal' | 'medical'
  var LEGAL = { ILLEGAL:'illegal', DECRIM:'decriminalise', TOLERE:'tolere', LEGAL:'legal', MEDICAL:'medical' };

  var REGIONS = {

    BE: {
      code:'BE', label:'Belgique', flag:'🇧🇪', lang:'fr', emergencyMain:'112',
      emergency:[
        { name:'Urgences médicales', tel:'112', desc:'Toutes urgences', kind:'urgence' },
        { name:'Centre Antipoisons', tel:'070 245 245', desc:'Overdose, intoxication — 24h/24', kind:'poison' },
        { name:'Télé-Accueil', tel:'107', desc:'Écoute psychologique gratuite — 24h/24', kind:'ecoute' },
        { name:'Drogues Info (Infor-Drogues)', tel:'02 227 52 52', desc:'Info, aide, orientation — anonyme', kind:'drogue' },
        { name:'Centre de Prévention du Suicide', tel:'0800 32 123', desc:'Crise suicidaire — 24h/24', kind:'suicide' }
      ],
      centres:[
        { name:'Modus Vivendi', desc:'Testing & RDR festif — Bruxelles', url:'modusvivendi-be.org' },
        { name:'Projet Lama', desc:'Addictions & santé mentale, sans liste d\u2019attente — BXL', url:'projetlama.be' },
        { name:'MASS Bruxelles', desc:'Maison d\u2019Accueil Socio-Sanitaire', url:'mass-bxl.be' },
        { name:'CAP Fly / Citadelle', desc:'Ambulatoire assuétudes — Liège', url:'' },
        { name:'Free Clinic', desc:'Consultations bas seuil — Anvers/BXL', url:'freeclinic.be' }
      ],
      groupes:[
        { name:'Narcotiques Anonymes', url:'na.org/fr', desc:'Réunions hebdomadaires' },
        { name:'Alcooliques Anonymes BE', url:'aa-fr.be', desc:'Partout en Belgique' },
        { name:'SMART Recovery', url:'smartrecovery.org', desc:'Approche cognitivo-comportementale' }
      ],
      testing:[ { name:'Modus Vivendi', desc:'Analyse de substances gratuite et confidentielle', url:'modusvivendi-be.org' } ],
      naloxone:{ access:'Sans ordonnance dans de nombreuses pharmacies ; kits via services RDR.', form:'Narcan nasal / Prenoxad injection' },
      legal:{
        verifie_le:'2026-06',
        cannabis:{ status:LEGAL.DECRIM, summary:'Possession ≤ 3 g (adulte) : tolérance/priorité basse, amende possible. Pas de vente légale.' },
        autres:{ status:LEGAL.ILLEGAL, summary:'Autres drogues illégales. Salles de consommation à moindre risque limitées.' },
        conduite:'Test salivaire au volant ; tolérance zéro pour les stupéfiants.',
        bonSamaritain:'Pas de loi « bon samaritain » dédiée, mais la non-assistance à personne en danger est punissable : appeler les secours protège.'
      },
      tips:[
        'La consultation chez le généraliste (DMG) facilite l\u2019accès remboursé à l\u2019addictologie.',
        'Naloxone (Narcan) disponible sans ordonnance dans beaucoup de pharmacies.',
        'Modus Vivendi propose du testing gratuit et confidentiel.'
      ]
    },

    FR: {
      code:'FR', label:'France', flag:'🇫🇷', lang:'fr', emergencyMain:'15',
      emergency:[
        { name:'SAMU', tel:'15', desc:'Urgences médicales', kind:'urgence' },
        { name:'Urgences (UE)', tel:'112', desc:'Toutes urgences', kind:'urgence' },
        { name:'Centre Antipoison', tel:'01 40 05 48 48', desc:'Intoxication, overdose', kind:'poison' },
        { name:'Drogues Info Service', tel:'0800 23 13 13', desc:'Gratuit, anonyme — 7j/7', kind:'drogue' },
        { name:'Alcool Info Service', tel:'0980 980 930', desc:'Accompagnement alcool', kind:'drogue' },
        { name:'Num. National Prévention Suicide', tel:'3114', desc:'24h/24, gratuit', kind:'suicide' }
      ],
      centres:[
        { name:'CSAPA', desc:'Soin, accompagnement, prévention en addictologie', url:'federationaddictions.fr' },
        { name:'CAARUD', desc:'Accueil & réduction des risques', url:'federationaddictions.fr' },
        { name:'Techno+', desc:'RDR & testing en milieu festif', url:'technoplus.org' },
        { name:'Fédération Addictions', desc:'Annuaire de professionnels', url:'federationaddictions.fr' }
      ],
      groupes:[
        { name:'NA France', url:'narcotiques-anonymes.fr', desc:'Narcotiques Anonymes' },
        { name:'AA France', url:'alcooliques-anonymes.fr', desc:'Alcooliques Anonymes' },
        { name:'Al-Anon France', url:'al-anon-alateen.fr', desc:'Pour les proches' }
      ],
      testing:[ { name:'Techno+ / CAARUD', desc:'Analyse de produit (festivals, permanences)', url:'technoplus.org' } ],
      naloxone:{ access:'Disponible (Nalscue/Prenoxad) ; kits via CAARUD et médecins.', form:'Spray nasal / injectable' },
      legal:{
        verifie_le:'2026-06',
        cannabis:{ status:LEGAL.ILLEGAL, summary:'Illégal. Usage = amende forfaitaire délictuelle 200 €. Cannabis médical : cadre restreint.' },
        autres:{ status:LEGAL.ILLEGAL, summary:'Stupéfiants illégaux. Quelques dispositifs RDR (salles de consommation expérimentales).' },
        conduite:'Test salivaire ; tolérance zéro : tout dépistage positif est une infraction.',
        bonSamaritain:'Pas de loi « bon samaritain » drogue dédiée ; la non-assistance à personne en danger est un délit : appeler le 15/112 est protégé dans son principe.'
      },
      tips:[
        'Mon Soutien Psy : séances de psychologue remboursées sur prescription.',
        'Le médecin généraliste peut prescrire méthadone ou buprénorphine.',
        'Drogues Info Service : 0 800 23 13 13, gratuit et anonyme.'
      ]
    },

    CH: {
      code:'CH', label:'Suisse', flag:'🇨🇭', lang:'fr', emergencyMain:'144',
      emergency:[
        { name:'Urgences médicales', tel:'144', desc:'Ambulance', kind:'urgence' },
        { name:'Tox Info Suisse', tel:'145', desc:'Intoxications — 24h/24', kind:'poison' },
        { name:'La Main Tendue', tel:'143', desc:'Écoute psychologique — 24h/24', kind:'ecoute' },
        { name:'Pro Juventute', tel:'147', desc:'Aide aux jeunes', kind:'ecoute' }
      ],
      centres:[
        { name:'Fondation Phénix', desc:'Traitement ambulatoire — Genève', url:'phenix.ch' },
        { name:'ARUD', desc:'Traitement des dépendances — Zurich', url:'arud.ch' },
        { name:'Addiction Suisse', desc:'Prévention & information nationale', url:'addictionsuisse.ch' }
      ],
      groupes:[
        { name:'NA Suisse Romande', url:'na.org/fr', desc:'Narcotiques Anonymes' },
        { name:'AA Suisse', url:'aasri.org', desc:'Alcooliques Anonymes' }
      ],
      testing:[ { name:'DIZ / Nuit blanche ? / Saferparty', desc:'Drug-checking (Zurich, Berne, Genève…)', url:'saferparty.ch' } ],
      naloxone:{ access:'Disponible en pharmacie ; programmes take-home.', form:'Spray nasal / injectable' },
      legal:{
        verifie_le:'2026-06',
        cannabis:{ status:LEGAL.DECRIM, summary:'Possession ≤ 10 g décriminalisée (amende d\u2019ordre). Projets pilotes de vente légale encadrée à Bâle, Berne, Genève, Zurich. Médical sur ordonnance.' },
        autres:{ status:LEGAL.ILLEGAL, summary:'Autres drogues illégales. Salles de consommation légales (Berne, Bâle, Zurich, Genève).' },
        conduite:'Test salivaire ; tolérance zéro pour les stupéfiants au volant.',
        bonSamaritain:'Devoir d\u2019assistance ; appeler les secours est attendu et protégé dans son principe.'
      },
      tips:[
        'La LAMal couvre les soins en addictologie.',
        'Salles de consommation à moindre risque dans plusieurs villes.',
        'Drug-checking disponible (Saferparty, DIZ).'
      ]
    },

    CA: {
      code:'CA', label:'Canada (QC)', flag:'🇨🇦', lang:'fr', emergencyMain:'911',
      emergency:[
        { name:'Urgences', tel:'911', desc:'Toutes urgences', kind:'urgence' },
        { name:'Centre antipoison du Québec', tel:'1 800 463-5060', desc:'Intoxications — 24h/24', kind:'poison' },
        { name:'Drogue : aide et référence', tel:'1 800 265-2626', desc:'Gratuit — 24h/24', kind:'drogue' },
        { name:'Ligne prévention du suicide', tel:'1 866 277-3553', desc:'1 866 APPELLE — 24h/24', kind:'suicide' }
      ],
      centres:[
        { name:'GRIP Montréal', desc:'RDR & analyse de substances', url:'gripmontreal.org' },
        { name:'CRAN', desc:'Réadaptation en dépendances — Montréal', url:'cran.qc.ca' },
        { name:'Portage', desc:'Résidentiel & communautaire', url:'portage.ca' }
      ],
      groupes:[
        { name:'NA Québec', url:'naquebec.org', desc:'Narcotiques Anonymes' },
        { name:'AA Montréal', url:'aa-quebec.org', desc:'Alcooliques Anonymes' }
      ],
      testing:[ { name:'GRIP Montréal', desc:'Analyse de substances (bandelettes fentanyl, spectro)', url:'gripmontreal.org' } ],
      naloxone:{ access:'Gratuite en pharmacie (carte RAMQ) ; trousses take-home.', form:'Spray nasal / injectable' },
      legal:{
        verifie_le:'2026-06',
        cannabis:{ status:LEGAL.LEGAL, summary:'Légal (récréatif) — 21 ans au Québec. Achat via SQDC. Possession publique ≤ 30 g.' },
        autres:{ status:LEGAL.ILLEGAL, summary:'Autres drogues illégales (essais de décriminalisation hors QC).' },
        conduite:'Tolérance très basse ; dépistage salivaire au volant.',
        bonSamaritain:'Loi sur les bons samaritains secourant les victimes de surdose : protège de poursuites pour simple possession quand on appelle le 911.'
      },
      tips:[
        'Naloxone gratuite en pharmacie sur présentation de la carte RAMQ.',
        'GRIP Montréal : analyse de substances et bandelettes fentanyl.',
        'Les CLSC offrent des services en dépendances.'
      ]
    },

    LU: {
      code:'LU', label:'Luxembourg', flag:'🇱🇺', lang:'fr', emergencyMain:'112',
      emergency:[
        { name:'Urgences', tel:'112', desc:'Toutes urgences', kind:'urgence' },
        { name:'SOS Détresse', tel:'45 45 45', desc:'Écoute psychologique — 24h/24', kind:'ecoute' }
      ],
      centres:[
        { name:'JDH', desc:'Jugend- an Drogenhëllef — Luxembourg-Ville', url:'jdh.lu' },
        { name:'Abrigado', desc:'Centre de jour / drop-in & salle de consommation', url:'jdh.lu' },
        { name:'CePT', desc:'Prévention des toxicomanies', url:'cept.lu' }
      ],
      groupes:[ { name:'NA Luxembourg', url:'na.org', desc:'Narcotiques Anonymes' } ],
      testing:[ { name:'CePT / JDH', desc:'Information & orientation RDR', url:'cept.lu' } ],
      naloxone:{ access:'Programmes take-home via services spécialisés.', form:'Spray nasal / injectable' },
      legal:{
        verifie_le:'2026-06',
        cannabis:{ status:LEGAL.TOLERE, summary:'Possession ≤ 3 g tolérée (amende réduite) ; culture jusqu\u2019à 4 plants/foyer en privé. Pas de vente ni de clubs.' },
        autres:{ status:LEGAL.ILLEGAL, summary:'Autres drogues illégales ; dispositifs RDR (Abrigado).' },
        conduite:'Test salivaire ; tolérance zéro au volant.',
        bonSamaritain:'Devoir de porter secours ; appeler le 112 est attendu et protégé dans son principe.'
      },
      tips:[
        'La CNS rembourse les soins en addictologie.',
        'JDH : consultation anonyme sans rendez-vous ; Abrigado pour la RDR.'
      ]
    }

  };

  /* ---- Données routières détaillées (alcoolémie, stupéfiants, sanctions) ----
     Vérifié 2026-06. Sources : codes de la route nationaux, Touteleurope,
     LegiPermis, services gouvernementaux. Éducatif, pas un conseil juridique. */
  var ROADSIDE = {
    BE: { verifie_le:'2026-06',
      alcoolGeneral:'0,5 g/L (0,22 mg/L air expiré)',
      alcoolNovice:'0,5 g/L — pas de seuil abaissé pour les novices',
      drogues:'Tolérance zéro : toute trace de stupéfiant = infraction. Dépistage salivaire.',
      refus:'Refuser le dépistage est sanctionné comme un test positif.',
      sanction:'Amende, déchéance du droit de conduire, voire prison selon le taux/récidive.',
      sources:'Code de la route belge (réforme sécurité routière 2025).' },
    FR: { verifie_le:'2026-06',
      alcoolGeneral:'0,5 g/L (0,25 mg/L air expiré)',
      alcoolNovice:'0,2 g/L (permis probatoire, AAC, transport en commun) — quasi zéro',
      drogues:'Tolérance zéro : la moindre trace est un délit. Test salivaire, confirmation sanguine.',
      refus:'Refus = délit (jusqu’à 9 000 €, 6 points, 2 ans de prison).',
      sanction:'≥ 0,8 g/L : délit, jusqu’à 4 500 € et 2 ans. Cumul alcool+drogue (loi 11 juillet 2025) : jusqu’à 15 000 € et 5 ans.',
      sources:'Code de la route (L235-1/2), arrêté 13/12/2016, lois 9 & 11 juillet 2025.' },
    CH: { verifie_le:'2026-06',
      alcoolGeneral:'0,5 g/L (0,25 mg/L air expiré)',
      alcoolNovice:'0,1 g/L (permis à l’essai, pros, moniteurs) — tolérance quasi nulle',
      drogues:'Tolérance zéro pour les stupéfiants. Dépistage salivaire, prise de sang.',
      refus:'Refus assimilé à un résultat positif ; sanctions lourdes.',
      sanction:'Amende, retrait de permis (durée selon gravité), prison possible.',
      sources:'Loi fédérale sur la circulation routière (LCR/OCR).' },
    CA: { verifie_le:'2026-06',
      alcoolGeneral:'0,08 (80 mg/100 mL) = infraction criminelle ; 0,05–0,08 = sanctions provinciales',
      alcoolNovice:'Zéro alcool : conducteurs ≤ 21 ans et permis d’apprenti/probatoire (Québec)',
      drogues:'THC ≥ 2 ng/mL = infraction (≥ 5 ng/mL aggravée). Autres drogues : tolérance/impairment.',
      refus:'Refus du test = infraction criminelle, peines équivalentes à la conduite avec facultés affaiblies.',
      sanction:'Suspension immédiate, amende, casier criminel possible dès la 1re infraction.',
      sources:'Code criminel (C-46), Code de la sécurité routière du Québec.' },
    LU: { verifie_le:'2026-06',
      alcoolGeneral:'0,5 g/L (0,25 mg/L air expiré)',
      alcoolNovice:'0,2 g/L (permis < 2 ans, professionnels)',
      drogues:'Tolérance zéro pour les stupéfiants. Dépistage salivaire.',
      refus:'Refus sanctionné comme un test positif.',
      sanction:'Amende, retrait de permis, prison selon le taux/récidive.',
      sources:'Code de la route luxembourgeois.' }
  };
  Object.keys(ROADSIDE).forEach(function(c){ if (REGIONS[c]) REGIONS[c].roadside = ROADSIDE[c]; });

  // ---- API ----
  var ORDER = ['BE','FR','CH','CA','LU'];
  function get(code){ return REGIONS[code] || REGIONS.BE; }
  function list(){ return ORDER.map(function(c){ return REGIONS[c]; }); }
  function exists(code){ return !!REGIONS[code]; }
  function telHref(tel){ return 'tel:' + String(tel).replace(/[^+0-9]/g,''); }

  global.MD_REGIONS = REGIONS;
  global.MD_LEGAL_STATUS = LEGAL;
  global.MDRegions = { get:get, list:list, exists:exists, order:ORDER, telHref:telHref };
})(window);
