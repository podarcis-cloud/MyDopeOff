/* ============================================================================
   MyDope Off — interactions-fix.js  (correctif CRITIQUE-1 / MAJEUR-2 / FC-2)
   Module global SANS build (compatible <script src="interactions-fix.js">).

   CE QUE ÇA CORRIGE
   1. La gravité n'est PLUS jamais déduite d'un emoji (les emoji ont disparu du
      fichier → toutes les paires devenaient "danger", et l'inconnu "safe"/vert).
      Ici la gravité est une DONNÉE explicite.
   2. Une paire NON documentée et sans règle de classe = "caution" (JAUNE),
      JAMAIS verte. Aucune combinaison n'est présentée comme "sûre".
   3. Le matching se fait par identifiant canonique STRICT (plus de .includes()
      qui faisait matcher "méthamphetamine" sur la règle "amphetamine").

   COMMENT BRANCHER DANS psychochecker.html (remplacement minimal)
   --------------------------------------------------------------------------
   a) <script src="interactions-fix.js"></script>  (après la définition des
      maps `substances` et `aliases`, ou exposez-les sur window).
   b) Au démarrage, fournir au module de quoi résoudre les noms + classes :
        MDInteractions.configure({
          resolveId: (raw) => (window.aliases.get(raw.trim().toLowerCase())
                               || raw.trim().toLowerCase()),
          getCategories: (id) => {
            const rec = window.substances.get(id)
                     || [...window.substances.values()]
                          .find(s => s.nom.toLowerCase() === id);
            return rec ? rec.categories : [];
          }
        });
   c) Migrer la base existante UNE fois (voir MDInteractions.importLegacy plus bas)
      OU remplir MDInteractions.DB directement en re-taguant la gravité.
   d) Dans le clic "Analyser" :
        const res = MDInteractions.analyze([s1, s2, s3]);
        box.innerHTML = MDInteractions.render(res);   // ou votre propre rendu
   e) Ajouter le CSS de l'état "caution" (en bas de ce fichier, à copier dans la
      feuille de styles) — sinon le jaune ne s'affichera pas.
   ========================================================================== */
(function (global) {
  'use strict';

  /* Pas de niveau "safe" : on n'affirme jamais qu'un mélange est sûr. */
  var SEVERITY = { DANGER: 'danger', WARN: 'warn', CAUTION: 'caution', INFO: 'info' };
  var RANK = { danger: 0, warn: 1, caution: 2, info: 3 };

  /* ---- Base d'interactions documentées (gravité = donnée explicite) --------
     a / b = identifiants canoniques en minuscules.
     Reprenez ICI les paires de l'ancienne interactionsDB en attribuant à chacune
     une `severity`. Tant qu'une paire n'est pas re-taguée, traitez-la comme
     DANGER (fail-safe haut). Quelques exemples re-tagués : */
  var DB = [
    { a:'alcool', b:'fentanyl', severity:SEVERITY.DANGER,
      msg:"Dépression respiratoire potentialisée — arrêt respiratoire possible.",
      action:"Ne pas associer. Somnolence anormale : PLS, naloxone, appeler le 112/15." },
    { a:'cocaïne', b:'héroïne', severity:SEVERITY.DANGER,
      msg:"Speedball : le stimulant masque la dépression respiratoire de l'opioïde ; surdose à la redescente.",
      action:"Éviter. Jamais seul·e, naloxone à portée." },
    { a:'fentanyl', b:'xylazine', severity:SEVERITY.DANGER,
      msg:"La naloxone NE lève PAS la xylazine (non opioïde). Sédation profonde, plaies nécrotiques.",
      action:"Administrer la naloxone quand même + appeler les secours immédiatement." },
    { a:'cocaïne', b:'alcool', severity:SEVERITY.WARN,
      msg:"Formation de cocaéthylène, plus cardiotoxique et durable.",
      action:"Risque cardiaque accru : limiter, surveiller douleur thoracique." },
    { a:'lsd', b:'cannabis', severity:SEVERITY.WARN,
      msg:"Le cannabis peut transformer un trip gérable en bad trip intense.",
      action:"Éviter en phase de montée ; lieu calme, personne de confiance." }
    /* … COMPLÉTER avec toutes les paires existantes, chacune avec sa severity … */
  ];

  /* ---- Règles par classe : filet de sécurité quand la paire n'est pas listée */
  function pair(A, B, x, y){ return (A.has(x)&&B.has(y)) || (A.has(y)&&B.has(x)); }
  var CLASS_RULES = [
    { when:function(A,B){return A.has('opioïde')&&B.has('opioïde');}, severity:SEVERITY.DANGER,
      msg:"Deux opioïdes : dépression respiratoire additionnée, risque d'overdose.",
      action:"Naloxone à portée, jamais seul·e." },
    { when:function(A,B){return pair(A,B,'opioïde','dépresseur');}, severity:SEVERITY.DANGER,
      msg:"Opioïde + dépresseur (benzo/alcool/GHB…) : cause majeure d'overdoses mortelles.",
      action:"Éviter ; sinon doses minimales, naloxone, présence d'un tiers." },
    { when:function(A,B){return A.has('dépresseur')&&B.has('dépresseur');}, severity:SEVERITY.DANGER,
      msg:"Deux dépresseurs du SNC : sédation et dépression respiratoire additionnées, risque de coma.",
      action:"Éviter l'association." },
    { when:function(A,B){return pair(A,B,'imao','sérotoninergique');}, severity:SEVERITY.DANGER,
      msg:"IMAO + sérotoninergique (MDMA, stimulant, tryptamine, ISRS…) : syndrome sérotoninergique potentiellement mortel.",
      action:"À proscrire." },
    { when:function(A,B){return A.has('stimulant')&&B.has('stimulant');}, severity:SEVERITY.WARN,
      msg:"Charge cardiovasculaire additionnée (tension, fréquence, hyperthermie).",
      action:"Hydratation, pauses, surveiller le cœur." },
    { when:function(A,B){return pair(A,B,'stimulant','opioïde');}, severity:SEVERITY.WARN,
      msg:"« Speedball » : le stimulant masque la dépression respiratoire → surdose trompeuse à la redescente.",
      action:"Très risqué ; jamais seul·e, naloxone à portée." },
    { when:function(A,B){return pair(A,B,'stimulant','dépresseur');}, severity:SEVERITY.WARN,
      msg:"Effets opposés qui masquent l'intoxication de chacun ; charge cardiaque + surdose à la redescente.",
      action:"Éviter ; doses prudentes." },
    { when:function(A,B){return A.has('sérotoninergique')&&B.has('sérotoninergique');}, severity:SEVERITY.WARN,
      msg:"Risque additif de syndrome sérotoninergique (confusion, tremblements, fièvre).",
      action:"Espacer, doses prudentes." },
    { when:function(A,B){return A.has('anticholinergique')||B.has('anticholinergique');}, severity:SEVERITY.WARN,
      msg:"Substance délirante/anticholinergique : interactions imprévisibles (délire, hyperthermie, arythmie).",
      action:"Très prudent ; ne pas être seul·e." },
    { when:function(A,B){return pair(A,B,'dissociatif','dépresseur');}, severity:SEVERITY.WARN,
      msg:"Sédation + risque de vomissement en perte de conscience (fausse route).",
      action:"Position latérale de sécurité, présence d'un tiers." }
  ];

  /* ---- Dérivation des classes pharmaco depuis les catégories d'une fiche ---- */
  function classesFromCategories(categories){
    var cats = (categories || []).join(' ').toLowerCase();
    var c = new Set();
    if (/opioïde|opiac|nitazène|fentanyl|kratom/.test(cats)) c.add('opioïde');
    if (/benzo|thi[eé]nodiaz|barbituri|z-drug|hypnotique|gaba|dépresseur|alcool|sédatif|anxiolytique|antipsychotique|alpha-2 agoniste|pr[ée]curseur ghb|antiépileptique|myorelaxant|inhalant/.test(cats)) c.add('dépresseur');
    if (/stimulant|cathinone|amphét|phénidate|eugéroïque|xanthine/.test(cats)) c.add('stimulant');
    if (/imao|harmala|ayahuasca/.test(cats)) c.add('imao');
    if (/psychédélique|tryptamine|phénéthylamine|lysergamide|empathogène|entactogène|cathinone|stimulant|irsna|pr[ée]curseur sérotonine|phénylpipérazine|dox/.test(cats)) c.add('sérotoninergique');
    if (/dissociatif|arylcyclohexylamine|diarylethylamine|anesthésique/.test(cats)) c.add('dissociatif');
    if (/anticholinergique|délirant|antihistaminique|datura/.test(cats)) c.add('anticholinergique');
    if (/cannabino|noid/.test(cats)) c.add('cannabinoïde');
    return c;
  }

  /* ---- Configuration injectée par l'app -------------------------------------
     resolveId(raw) -> id canonique ; getCategories(id) -> [catégories]        */
  var cfg = {
    resolveId: function (raw){ return String(raw||'').trim().toLowerCase(); },
    getCategories: function (){ return []; },
    getClasses: null   // (id) -> [classes] ; prioritaire sur getCategories si fourni (table auditée)
  };
  function configure(opts){ if (opts) Object.assign(cfg, opts); }

  function classesOf(id){
    if (typeof cfg.getClasses === 'function') {
      var arr = cfg.getClasses(id);
      if (arr && arr.length) return new Set(arr);
      // table muette pour cet id -> on retombe sur le regex des catégories
    }
    return classesFromCategories(cfg.getCategories(id));
  }

  /* ---- Analyse d'une paire (cœur du correctif) ------------------------------ */
  function analyzePair(idA, idB){
    var hit = null;
    for (var i = 0; i < DB.length; i++){
      var d = DB[i];
      if ((d.a === idA && d.b === idB) || (d.a === idB && d.b === idA)) { hit = d; break; } // ÉGALITÉ stricte
    }
    var label = idA + ' + ' + idB;
    if (hit) return { pair: label, severity: hit.severity, msg: hit.msg, action: hit.action || '' };

    var A = classesOf(idA), B = classesOf(idB);
    for (var r = 0; r < CLASS_RULES.length; r++){
      if (CLASS_RULES[r].when(A, B)) {
        return { pair: label, severity: CLASS_RULES[r].severity, msg: CLASS_RULES[r].msg, action: CLASS_RULES[r].action || '' };
      }
    }
    /* INCONNU → prudence (jaune), JAMAIS vert. */
    return {
      pair: label, severity: SEVERITY.CAUTION,
      msg: "Aucune interaction spécifiquement documentée — cela ne veut PAS dire « sans risque ».",
      action: "Tout mélange est imprévisible : dose minimale, jamais seul·e, idéalement faire analyser le produit."
    };
  }

  /* ---- Analyse de la liste (toutes les paires), triée du pire au moins grave */
  function analyze(rawInputs){
    var ids = (rawInputs || [])
      .map(function (s){ return s && s.trim() ? cfg.resolveId(s) : ''; })
      .filter(function (s){ return s.length > 0; });
    // dédoublonnage
    ids = ids.filter(function (v, i){ return ids.indexOf(v) === i; });
    if (ids.length < 2) return { ok: false, reason: 'need_two', pairs: [] };

    var pairs = [];
    for (var i = 0; i < ids.length; i++)
      for (var j = i + 1; j < ids.length; j++)
        pairs.push(analyzePair(ids[i], ids[j]));

    pairs.sort(function (x, y){ return RANK[x.severity] - RANK[y.severity]; });
    return { ok: true, pairs: pairs };
  }

  /* ---- Rendu HTML sûr (échappe le contenu) ---------------------------------- */
  function esc(s){
    return String(s).replace(/[&<>"]/g, function (m){
      return { '&':'&amp;', '<':'&lt;', '>':'&gt;', '"':'&quot;' }[m];
    });
  }
  var SEV_LABEL = { danger:'Danger', warn:'Risque', caution:'Prudence', info:'Info' };
  function render(result){
    if (!result.ok) return "Entrez au moins 2 substances.";
    if (!result.pairs.length) return "Substance(s) non reconnue(s). Vérifiez l'orthographe.";
    var head = '<div class="ix-head">Analyse — ' + result.pairs.length + ' paire(s)</div>';
    return head + result.pairs.map(function (p){
      return '<div class="interaction-item ' + p.severity + '">'
           +   '<div class="interaction-pair">' + esc(p.pair.toUpperCase())
           +     ' · <span class="ix-badge">' + SEV_LABEL[p.severity] + '</span></div>'
           +   '<div class="ix-msg">' + esc(p.msg) + '</div>'
           +   (p.action ? '<div class="ix-action">→ ' + esc(p.action) + '</div>' : '')
           + '</div>';
    }).join('');
  }

  /* ---- Aide de migration : importer l'ancienne base sans perdre la sécurité --
     L'ancienne interactionsDB ([{a,b,msg}]) avait perdu sa gravité. On l'importe
     en marquant chaque paire DANGER par défaut (fail-safe), à re-tague ensuite. */
  function importLegacy(legacyArray, defaultSeverity){
    var sev = defaultSeverity || SEVERITY.DANGER;
    (legacyArray || []).forEach(function (d){
      if (!d || !d.a || !d.b) return;
      var a = cfg.resolveId(d.a), b = cfg.resolveId(d.b);
      var exists = DB.some(function (e){
        return (e.a === a && e.b === b) || (e.a === b && e.b === a);
      });
      if (!exists) DB.push({ a:a, b:b, severity:sev, msg:(d.msg||'').trim(), action:'' });
    });
  }

  global.MDInteractions = {
    SEVERITY: SEVERITY, DB: DB, CLASS_RULES: CLASS_RULES,
    configure: configure, analyze: analyze, analyzePair: analyzePair,
    render: render, importLegacy: importLegacy, classesFromCategories: classesFromCategories
  };
})(window);

/* ============================================================================
   CSS À AJOUTER (états de gravité) — copier dans la feuille de styles.
   IMPORTANT : il n'y a PAS de classe verte. L'inconnu est jaune ("caution").

   .interaction-item              { background:#fff; border-radius:4px; padding:12px 14px;
                                    margin-top:8px; border-left:4px solid #DC2626;   (danger)
                                    font-size:13px; line-height:1.6; }
   .interaction-item.warn         { border-left-color:#E07000; }    (orange)
   .interaction-item.caution      { border-left-color:#CA8A04;     (jaune)
                                    background:#FEFCE8; }
   .interaction-item.info         { border-left-color:#64748B; }
   .ix-head    { font-size:12px; letter-spacing:.1em; text-transform:uppercase;
                 color:#64748B; margin-bottom:8px; }
   .ix-badge   { font-weight:800; }
   .interaction-item.danger  .ix-badge { color:#DC2626; }
   .interaction-item.warn    .ix-badge { color:#E07000; }
   .interaction-item.caution .ix-badge { color:#CA8A04; }
   .ix-msg     { margin-top:2px; }
   .ix-action  { margin-top:6px; font-weight:600; color:#0F172A; }
   ========================================================================== */
