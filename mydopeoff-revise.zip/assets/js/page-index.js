/* MyDope Off — logique de page : index.html (externalisée pour CSP script-src 'self') */
// Pas de profil -> onboarding. Le profil vient UNIQUEMENT du stockage local (plus aucune donnée transmise via l'URL).
var u = MDCore.user();
if (!u || !u.name) { location.replace('inscription.html'); }
else {
  MDCore.init({ page:'index' });

  var ageWord = function(){ return ({fr:'ans',en:'y/o',es:'años',de:'J.'})[MDCore.lang()] || 'ans'; };
  function paintProfile(){
    document.getElementById('hello').textContent = MDCore.t('home.hello') + ' ' + u.name;
    var reg = MDRegions.exists(u.region) ? MDRegions.get(u.region).label : (u.region||'BE');
    document.getElementById('prof-sub').textContent = u.name + (u.age ? ' · '+u.age+' '+ageWord() : '') + ' · ' + reg;
  }
  paintProfile();
  document.addEventListener('langchange', paintProfile);

  // Streak de sobriété (lecture seule du journal local)
  (function(){
    function dstr(k){ var t=new Date(); t.setDate(t.getDate()-k); return t.toISOString().slice(0,10); }
    try{
      var sv = JSON.parse(localStorage.getItem('ctc_v6_suivi'));
      if (sv && sv.entries && sv.entries.length){
        var st=0;
        for (var k=0;k<365;k++){
          var e = sv.entries.filter(function(x){ return x.date===dstr(k); });
          if (!e.length) break;
          if (Math.max.apply(null, e.map(function(x){ return x.intensity; }))===0) st++; else break;
        }
        if (st>0){
          var el=document.getElementById('status'); el.hidden=false;
          el.innerHTML = '<svg viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="#16A34A" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M20 6 9 17l-5-5"/></svg>'+
            '<div><div class="l-name">'+st+' '+(MDCore.lang()==='en'?'sober day'+(st>1?'s':''):'jour'+(st>1?'s':'')+' sobre'+(st>1?'s':''))+'</div>'+
            '<div class="l-sub">'+MDCore.t({fr:'Continue, ton cerveau récupère.',en:'Keep going, your brain is recovering.',es:'Sigue, tu cerebro se recupera.',de:'Weiter so, dein Gehirn erholt sich.'})+'</div></div>';
        }
      }
    }catch(e){}
  })();
}
